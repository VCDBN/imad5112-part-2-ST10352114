package com.example.kotlincalculatorp1
//had some trouble renaming my package, it just did not work
//Muhammed-Safwaan-Ally-ST10352114
//Varsity College Durban North
//There are no changes made from part 1 to 2
//https://www.loom.com/share/680f65f42d384d4b99d934c21e4706b3?sid=ae96400d-f2b7-45c3-b1e9-07fdcc6e7378

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.annotation.SuppressLint
import kotlin.math.sqrt
import kotlin.math.pow



class MainActivity : AppCompatActivity() {

    //www.youtube.com. (n.d.). Simple Calculator Using Kotlin. [online] Available at: https://youtu.be/Zi1XgFTUH9k?si=Ar-_XKP4OgvcI4KX [Accessed 18 Sep. 2023].


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


//setting our variables and view by ids
//creating our calculator buttons and assigning them

        val number1 = findViewById<EditText>(R.id.Number1)
        val number2 = findViewById<EditText>(R.id.Number2)
        val answerTextView = findViewById<TextView>(R.id.Answer)
        val multiplicationButton = findViewById<Button>(R.id.Multiplication)
        val divisionButton = findViewById<Button>(R.id.Division)
        val subtractionButton = findViewById<Button>(R.id.Subtraction)
        val additionButton = findViewById<Button>(R.id.Addition)
        val squareRootButton = findViewById<Button>(R.id.SquareRoot)
        val powerButton = findViewById<Button>(R.id.Power)


//setting on click listeners for each of our calculator buttons
        multiplicationButton.setOnClickListener {

            //use the toInt() to convert to an integer and allows for return
            val multiplynumber1 = number1.text.toString().toInt()
            val multiplynumber2 = number2.text.toString().toInt()

            val answer = multiplynumber1 * multiplynumber2
            //use the $ to get the exact value of the answer and the 2 numbers
            answerTextView.text = "$multiplynumber1 * $multiplynumber2 = $answer"
        }

        divisionButton.setOnClickListener {
//this is the divison button
            val dividenumber1 = number1.text.toString().toInt()
            val dividenumber2 = number2.text.toString().toInt()
//In part 2 I have added the error message to display when you try to divide by 0
            if (dividenumber2 == 0) {
                answerTextView.text = "Error: Division by zero is not allowed."
            } else {
                val answer = dividenumber1.toDouble() / dividenumber2.toDouble()
                answerTextView.text = "$dividenumber1 / $dividenumber2 = $answer"
            }

        }

        subtractionButton.setOnClickListener {

            val minusnumber1 = number1.text.toString().toInt()
            val minusnumber2 = number2.text.toString().toInt()

            val answer = minusnumber1 - minusnumber2
            answerTextView.text = "$minusnumber1 - $minusnumber2 = $answer"
        }

        additionButton.setOnClickListener {

            val addnumber1 = number1.text.toString().toInt()
            val addnumber2 = number2.text.toString().toInt()

            val answer = addnumber1 + addnumber2
            answerTextView.text = "$addnumber1 + $addnumber2 = $answer"
        }

        squareRootButton.setOnClickListener {
//this function is new to my calculator app
            val inputNumber = number1.text.toString().toDouble()
//the correct display of the answer has been added here as according to the POE
//I have used else if statements to ensure a smooth run of operations, keeping it short and sweet
            if (inputNumber >= 0) {
                val squareRoot = sqrt(inputNumber)
                answerTextView.text = "sqrt($inputNumber) = $squareRoot"
            } else {
                val absValue = kotlin.math.abs(inputNumber)
                val imaginarySquareRoot = sqrt(absValue)
                //I have added i for imaginary number, id the 1st number is negative
                //meaning below 0
                answerTextView.text = "sqrt($inputNumber) = ${imaginarySquareRoot}i"
            }

        }

        powerButton.setOnClickListener {

            val base = number1.text.toString().toDouble()
            val exponent = number2.text.toString().toInt()

            var result = 1.0
//the correct display of the answer has been added here as according to the POE requirements for Part 2
            if (exponent >= 0) {
                for (i in 1..exponent) {
                    result *= base
                }
                answerTextView.text = "$base^$exponent = $result"
            } else {
                answerTextView.text = "Error: Negative exponent is not allowed."
            }
        }

    }
}

